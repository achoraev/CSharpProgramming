﻿using System;

    class WriteName
    {
        static void Main()
        {
            Console.WriteLine("Ivailo Petrov");
        }
    }

