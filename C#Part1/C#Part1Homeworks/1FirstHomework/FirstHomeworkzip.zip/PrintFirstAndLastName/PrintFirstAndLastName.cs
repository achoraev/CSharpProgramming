﻿using System;

    class PrintFirstAndLastName
    {
        static void Main()
        {
            Console.WriteLine("First Name: Ivailo");
            Console.WriteLine("Last Name: Penchev");   
        }
    }
