﻿using System;

class HelloC
{
	static void Main()
	{
		Console.WriteLine("Hello C#");
	}
}