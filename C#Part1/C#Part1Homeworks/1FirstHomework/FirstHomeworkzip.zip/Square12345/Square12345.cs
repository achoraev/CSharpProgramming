﻿using System;

    class Square12345
    {
        static void Main()
        {
            long square = 12345;
            Console.WriteLine(Math.Pow(square, 2));
        }
    }

