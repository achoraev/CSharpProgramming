﻿using System;

    class CaseFiveGoodDay
    {
        static void Main()
        {
            Console.WriteLine("Добър ден");
        }
    }

