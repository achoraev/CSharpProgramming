﻿using System;

    class PrintDateTime
    {
        static void Main()
        {
            DateTime Date = DateTime.Now;
            Console.WriteLine(Date);
        }
    }
