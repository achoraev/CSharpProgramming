﻿using System;

    class MarketingFirm
    {
        static void Main()
        {
            string firstName = "Ivailo";
            string familyName = "Penchev";
            byte age = 25;
            char gender = 'm';
            int id = 123456789;
            int number = 27560000;
            Console.WriteLine(firstName + " " + familyName + " " + age + " " + gender + " " + id + " " + number); 
        }
    }
