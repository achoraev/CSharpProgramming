﻿using System;

    class BankAccount
    {
        static void Main()
        {
            string firstName = "Ivailo";
            string middleName = "Hristov";
            string lastName = "Penchev";
            decimal balance = 10000000000536.97m;
            string bankName = "Eurobank";
            string IBAN = "BG19BPBI79421072112301";
            string bicCode = "BGSFBPBI";
            long firstCardNumber = 1234567891235468;
            long secondCardNumber = 2345564595424568;
            long thirdCardNumber = 5426545647894568;
            Console.WriteLine(firstName);
            Console.WriteLine(middleName);
            Console.WriteLine(lastName);
            Console.WriteLine(balance);
            Console.WriteLine(bankName);
            Console.WriteLine(IBAN);
            Console.WriteLine(bicCode);
            Console.WriteLine(firstCardNumber);
            Console.WriteLine(secondCardNumber);
            Console.WriteLine(thirdCardNumber);
        }
    }

