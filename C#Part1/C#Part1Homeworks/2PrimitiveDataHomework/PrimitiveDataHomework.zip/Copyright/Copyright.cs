﻿using System;

    class Copyright
    {
        static void Main()
        {           
            Console.WriteLine("   ©");
            Console.WriteLine("  © ©");
            Console.WriteLine(" ©   ©");
            Console.WriteLine("© © © ©");
        }
    }
