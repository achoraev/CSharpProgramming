﻿using System;

    class DeclareChar
    {
        static void Main()
        {
            char unicode = '\u0048';
            Console.WriteLine(unicode);            
        }
    }
