﻿using System;

    class DeclareVariables
    {
        static void Main()
        {
            byte first = 97;
            sbyte second = -115;
            short third = - 10000;
            ushort fourth = 52130;
            int five = 4825932;
            Console.WriteLine("Byte {0} Sbyte {1} Short {2} Ushort {3} Int {4}",first, second, third, fourth, five);
        }
    }
