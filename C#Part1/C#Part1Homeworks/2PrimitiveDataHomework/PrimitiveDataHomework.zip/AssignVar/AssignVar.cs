﻿using System;

    class AssignVar
    {
        static void Main()
        {
            float first = 12.345f;
            float second = 8923.1234857f;
            float third = 3456.091f;
            double four = 34.567839023d;
            decimal five = 1.2544555848456456456456412316789456156m;
            Console.WriteLine("float " + first);
            Console.WriteLine("float " + second);
            Console.WriteLine("float " + third);
            Console.WriteLine("double " + four);
            Console.WriteLine("decimal " + five);
        }
    }
