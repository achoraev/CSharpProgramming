﻿using System;

class DeclareHexadecimal
    {
        static void Main()
        {
            int hexadecimal = 0x00FE;
            Console.WriteLine(hexadecimal);
        }
    }   