﻿namespace IfStatements
{
    using System;

    public class Potato
    {
        public bool HasNotBeenPeeled { get; set; }

        public bool IsRotten { get; set; }
    }
}
