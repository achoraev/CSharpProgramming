﻿namespace ClassChef
{
    using System;
    
    public class Vegetable
    {
    }
}
