﻿namespace ClassChef
{
    using System;   

    public class Carrot : Vegetable
    {
    }
}
