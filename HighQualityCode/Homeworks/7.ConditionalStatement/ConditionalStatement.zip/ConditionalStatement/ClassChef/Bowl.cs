﻿namespace ClassChef
{
    using System;
    
    public class Bowl
    {        
        internal void Add(Potato potato)
        {
            throw new NotImplementedException();
        }
        
        internal void Add(Carrot carrot)
        {
            throw new NotImplementedException();
        }
    }
}
