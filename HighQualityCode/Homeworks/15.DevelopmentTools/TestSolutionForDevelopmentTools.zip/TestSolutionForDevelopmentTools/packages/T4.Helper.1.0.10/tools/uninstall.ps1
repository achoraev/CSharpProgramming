param($installPath, $toolsPath, $package, $project)

Remove-Module 'T4.Helper'
