param($installPath, $toolsPath, $package, $project)

Remove-Module 'EnvDTE.Helper'
