Install JustMock trial and reference it to the tests project
http://www.telerik.com/products/mocking.aspx