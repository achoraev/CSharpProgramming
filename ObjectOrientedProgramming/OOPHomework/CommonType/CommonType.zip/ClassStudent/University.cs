namespace CommonType
{
	using System;
	public enum University
	{
        Technical, FMI, Unspecified
	}	
}