namespace CommonType
{
	using System;
	public enum Specialty
	{
        Biotechnology, Chemistry, ComputerSystems, Unspecified
	}	
}