namespace CommonType
{
	using System;
	public enum Faculty
	{
        Biology, Chemistry, IT, Unspecified
	}	
}