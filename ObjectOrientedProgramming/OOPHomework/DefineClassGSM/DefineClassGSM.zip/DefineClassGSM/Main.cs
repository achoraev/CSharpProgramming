﻿namespace DefineClassGSM
{
    using System;
    public class Tests
    {
        static void Main()
        {
            GSMTest.Test();
            Console.WriteLine();
            GSMCallHistoryTest.CallTest();
        }
    }
}
