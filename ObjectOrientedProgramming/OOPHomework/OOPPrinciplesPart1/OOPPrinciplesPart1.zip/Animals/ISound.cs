namespace classAnimals
{
	using System;
	
	public interface ISound
	{		
		void MakeSound();
	}
}