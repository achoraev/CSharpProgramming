namespace OopPrinciplesPart2
{
	using System;	
	
	public interface IWithdraw
	{		
		void Withdraw(int withdraw);
	}
}