namespace OopPrinciplesPart2
{
	using System;	
	
	public interface IDeposit
	{		
		void Deposit(int deposit);
	}
}