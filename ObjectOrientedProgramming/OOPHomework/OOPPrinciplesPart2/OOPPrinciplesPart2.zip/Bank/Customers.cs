namespace OopPrinciplesPart2
{
	using System;	
	
	public enum Customers
	{
		Individuals,
		Companies	
	}	
}